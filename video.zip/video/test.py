import csv
import json
import os
import random
import time
import openpyxl
import xlrd as xlrd
import startInfo
from datetime import datetime
import threading
import concurrent.futures

# 下面不用动
folder_path = 'file/Joe_Biden'

# 多线程
if __name__ == '__main__':
    all_num = 0
    # 获取文件夹中的所有文件
    file_list = os.listdir(folder_path)
    print(f"视频个数：{len(file_list)}")
    # 循环处理每个文件读取video_id_arr
    for file_name in file_list:
        if file_name.endswith('.json'):  # 确保是 csv 文件
            # print(file_name)
            file_name_str, _ = os.path.splitext(file_name)
            file_path = os.path.join(folder_path, file_name)  # 获取文件的完整路径
            # 读取原始数据
            with open(file_path, 'r', newline='', encoding='utf-8') as file:
                rows = json.load(file)
                all_num += len(rows)
    print(f"总条数：{all_num}")
    print(f"平均：{int(all_num/len(file_list))}")