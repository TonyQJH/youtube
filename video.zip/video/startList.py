import asyncio
import csv
import time
import xlwt
from datetime import datetime
import random
import concurrent.futures
import re
import json
import os
import threading
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
import selenium.webdriver.support.expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.action_chains import ActionChains


class nhAirRegister:
    # 初始化控制器和浏览器
    def __init__(self):
        print(f"启动中")
        options = webdriver.ChromeOptions()
        options.add_experimental_option("excludeSwitches", ["enable-logging"])
        options.add_experimental_option("excludeSwitches", ["enable-automation", "enable-logging"])  # 上面两个可以同时设置
        # options.add_argument("--headless")  # 无头模式
        prefs = {"profile.managed_default_content_settings.images": 2}  # 设置无图模式
        options.add_experimental_option("prefs", prefs)  # 加载无图模式设置
        options.add_argument("--disable-gpu")  # 上面代码就是为了将Chrome不弹出界面
        options.add_argument("--incognito")  # 无痕隐身模式
        options.add_argument("disable-cache")  # 禁用缓存
        options.add_argument("disable-infobars")
        options.add_argument("log-level=3")
        options.add_argument("--disable-software-rasterizer")
        options.set_capability('goog:loggingPrefs', {'performance': 'ALL'})
        service = Service(executable_path="chromedriver.exe")
        self.browser = webdriver.Chrome(service=service, options=options)
        with open("./stealth.min.js") as f:
            js = f.read()
        self.browser.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {"source": js})
        self.browser.set_window_position(x=0, y=0)
        print(f"启动完毕")

    # 开始
    def start(self, words, time_str):
        all_datas = []
        # 设置页面加载超时时间为10秒
        # try:
        self.browser.set_page_load_timeout(30)
        self.browser.get(f"https://www.youtube.com/results?search_query={words}&sp={time_str}")
        # 等待网页加载完成
        WebDriverWait(self.browser, 10).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, 'input#search'))
        )
        # 获取输入框并输入
        # search_input = self.browser.find_element(By.CSS_SELECTOR, 'input#search')
        # search_input.send_keys(words)
        # print(f"输入关键词：{words}")
        # time.sleep(1)
        # # 获取搜索按钮并点击
        # search_input_button = self.browser.find_element(By.CSS_SELECTOR, 'button#search-icon-legacy')
        # search_input_button.click()
        time.sleep(5)
        print(f"{words} 开始下滑加载,请等待。。。")
        # 模拟向下滚动
        for _ in range(100):
            # 判断没有更多数据
            if 'No more results' in self.browser.page_source:
                break
            # 滚动到页面底部
            self.browser.execute_script("window.scrollBy(0,10000)")
            print(f"{words} 下滑次数：{_ + 1}")
            # 等待页面加载
            time.sleep(1)
        time.sleep(2)
        # 获取所有网络请求记录
        logs = self.browser.get_log('performance')
        # 解析请求，获取响应体信息
        for log in logs:
            message = json.loads(log['message'])['message']
            if 'Network.responseReceived' in message['method']:
                if 'response' in message['params']:
                    response_url = message['params']['response']['url']
                    if response_url == 'https://www.youtube.com/youtubei/v1/search?prettyPrint=false':
                        body = self.browser.execute_cdp_cmd("Network.getResponseBody",
                                                            {"requestId": message['params']['requestId']})['body']
                        # 请求响应的数据
                        json_body = json.loads(body)
                        # 剥洋葱
                        # 第一种情况
                        if 'contents' in json_body:
                            if 'twoColumnSearchResultsRenderer' in json_body['contents']:
                                try:
                                    datas = json_body['contents']['twoColumnSearchResultsRenderer']['primaryContents'][
                                        'sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents']
                                    for item in datas:
                                        if 'videoRenderer' in item:
                                            item_data = item['videoRenderer']
                                            videoId = item_data['videoId']
                                            title = item_data['title']['runs'][0]['text']
                                            time_str = item_data['publishedTimeText']['simpleText']
                                            num = item_data['viewCountText']['simpleText']
                                            all_datas.append([videoId, title, time_str, num])
                                            # print(videoId, title, time_str, num)
                                except:
                                    pass
                        # 第二种情况
                        if 'onResponseReceivedCommands' in json_body:
                            try:
                                datas = json_body['onResponseReceivedCommands'][0]['appendContinuationItemsAction'][
                                    'continuationItems'][0][
                                    'itemSectionRenderer']['contents']
                                for item in datas:
                                    if 'videoRenderer' in item:
                                        item_data = item['videoRenderer']
                                        videoId = item_data['videoId']
                                        title = item_data['title']['runs'][0]['text']
                                        time_str = item_data['publishedTimeText']['simpleText']
                                        num = item_data['viewCountText']['simpleText']
                                        all_datas.append([videoId, title, time_str, num])
                                        # print(videoId, title, time_str, num)
                            except:
                                pass
        print(f'{words} 数据条数：{len(all_datas)}')
        # 写csv
        # 保存工作簿到文件
        xls_name = words.replace(" ", '_')
        list_datas = []
        for i in range(0, len(all_datas)):
            datas_i = all_datas[i]
            list_datas.append(
                {'video_id': datas_i[0], 'title': datas_i[1], 'upload_time': "", 'count_view': datas_i[3], 'description': '', 'count_like': '',
                 'count_comment': '', 'comment': ''})
        json_file_path = f'file/{xls_name}.json'
        if not os.path.exists(json_file_path):
            with open(json_file_path, 'w', newline='', encoding='utf-8') as file:
                str_list_datas = json.dumps(list_datas, ensure_ascii=False)
                file.write(str_list_datas)
        else:
            with open(json_file_path, 'r', newline='', encoding='utf-8') as file:
                existing_datas = json.load(file)
                for existing_data in existing_datas:
                    list_datas.append(existing_data)
                with open(json_file_path, 'w', newline='', encoding='utf-8') as file:
                    str_list_datas = json.dumps(list_datas, ensure_ascii=False)
                    file.write(str_list_datas)
        print(f"{xls_name}.json：生成完成")
        # except:
        #     pass

    # 后面不用管
    def wait(self, value, timeout=20):
        b = self.browser
        res = True
        try:
            WebDriverWait(b, timeout, 0.5).until(lambda b: b.find_element(By.XPATH, value))
            res = True
        except Exception as e:
            res = False
        return res

    def find_element(self, xpath):
        return self.browser.find_element(By.XPATH, xpath)

    def find_elements(self, xpath):
        return self.browser.find_elements(By.XPATH, xpath)

    def goBottom(self):
        self.browser.execute_script("window.scrollTo(0,document.body.scrollHeight);")

    def close(self):
        self.browser.quit()
