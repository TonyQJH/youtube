import json
import random
import time

import startList
from datetime import datetime
import threading
import concurrent.futures

# 关键词
words_arr = ["Nikki Haley"]
# 时间  今天 本周 本月 本年 标识码
time_arr = ["EgIIAg%253D%253D", "EgQIAxAB", "EgQIBBAB", "EgQIBRAB"]
# 最大线程数
max_threads = 8
# 下面不动
is_use = False


def start_web():
    global is_use
    # 挨个读取关键词
    words = words_arr.pop(0)
    while True:
        if not is_use:
            is_use = True
            break
        time.sleep(1)
    r = None
    try:
        r = startList.nhAirRegister()
        is_use = False
        # 时间
        for time_str in time_arr:
            r.start(words,time_str)
    except:
        pass
    finally:
        if r:
            r.close()


# 多线程
if __name__ == '__main__':
    # 获取当前时间
    current_time = datetime.now()
    print(f"关键词个数: {len(words_arr)}")
    words_arr = list(dict.fromkeys(words_arr))
    print(f"去重后关键词个数: {len(words_arr)}")
    # 任务总数
    total_tasks = len(words_arr)
    # 创建线程池
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
        tasks = [executor.submit(start_web) for _ in range(total_tasks)]
        # 等待所有任务完成
        concurrent.futures.wait(tasks, return_when=concurrent.futures.ALL_COMPLETED)
    # 打印年月日时分秒
    print(f"开始时间: {current_time}")
    # 获取当前时间
    current_time = datetime.now()
    # 打印年月日时分秒
    print(f"结束时间: {current_time}")
    print("所有任务已完成")
