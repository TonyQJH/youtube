import csv
import json
import os
import random
import time
import openpyxl
import xlrd as xlrd
import startInfo
from datetime import datetime
import threading
import concurrent.futures

# 最大线程数 修改
max_threads = 25
# 下面不用动
folder_path = 'file'
video_id_arr = []
file_path = ''
file_name_str = ""
is_use = False


def start_web():
    global is_use
    # 挨个读取关键词
    video_id = video_id_arr.pop(0)
    while True:
        if not is_use:
            is_use = True
            break
        time.sleep(1)
    r = None
    try:
        r = startInfo.nhAirRegister()
        is_use = False
        r.start(video_id, file_name_str, file_path)
    except:
        pass
    finally:
        if r:
            r.close()


# 多线程
if __name__ == '__main__':
    # 获取文件夹中的所有文件
    file_list = os.listdir(folder_path)
    # 循环处理每个文件读取video_id_arr
    for file_name in file_list:
        if file_name.endswith('.json'):  # 确保是 csv 文件
            print(file_name)
            # 拆分文件名和扩展名
            file_name_str, _ = os.path.splitext(file_name)
            file_path = os.path.join(folder_path, file_name)  # 获取文件的完整路径
            # 读取原始数据
            with open(file_path, 'r', newline='', encoding='utf-8') as file:
                rows = json.load(file)
            for row in rows:
                cell_value = row["video_id"]  # 读取第一列数据
                pl_value = row["comment"]  # 评论
                if not pl_value:
                    video_id_arr.append(cell_value)
            # 获取当前时间
            current_time = datetime.now()
            print(f"总视频id个数: {len(rows)}")
            print(f"剩余视频id个数: {len(video_id_arr)}")
            video_id_arr = list(dict.fromkeys(video_id_arr))
            print(f"去重后视频id个数: {len(video_id_arr)}")
            # 任务总数
            total_tasks = len(video_id_arr)
            # 创建线程池
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
                tasks = [executor.submit(start_web) for _ in range(total_tasks)]
                # 等待所有任务完成
                concurrent.futures.wait(tasks, return_when=concurrent.futures.ALL_COMPLETED)
            # 打印年月日时分秒
            print(f"开始时间: {current_time}")
            # 获取当前时间
            current_time = datetime.now()
            # 打印年月日时分秒
            print(f"结束时间: {current_time}")
            print("所有任务已完成")
