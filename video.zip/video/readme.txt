（逻辑）
1.加载目标网站   https://www.youtube.com
2.搜索  输入关键词  2024 US Presidential Election
3.点击搜索按钮
4. a.能直接拿到原始的请求数据  b.页面中分析元素 提取数据

5. 搜索结果页面   =》视频的链接,标题,发布人
6. 通过视频链接=》进入详情页面  =》 描述,评论(1w)

7. 去重，时间区间 ，必要信息（删除非必要）
8. 所有的结果数据


（代码）
1. python
2. webdriver => from selenium import webdriver(实现)
3. 上面逻辑实现

