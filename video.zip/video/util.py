import csv
import json

import xlwt
import xlrd
from xlutils.copy import copy


# 修改固定列值
def update_csv_row(file_path, video_id, new_data):
    # 读取原始数据
    with open(file_path, 'r', newline='', encoding='utf-8') as file:
        rows = json.load(file)
    # 查找并更新特定行的数据
    updated_rows = []
    for row in rows:
        if row["video_id"] == video_id:
            row.update(new_data)
        updated_rows.append(row)
    with open(file_path, 'w', encoding='utf-8') as file:
        str_all_datas = json.dumps(updated_rows, ensure_ascii=False)
        file.write(str_all_datas)
    print(f"{video_id} 修改成功！！")


# json找key
def deep_search(data, key):
    if isinstance(data, dict):
        for k, v in data.items():
            if k == key:
                return v
            elif isinstance(v, (dict, list)):
                result = deep_search(v, key)
                if result is not None:
                    return result
    elif isinstance(data, list):
        for item in data:
            result = deep_search(item, key)
            if result is not None:
                return result
    return None
