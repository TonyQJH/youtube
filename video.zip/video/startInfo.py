import asyncio
import os
import time

import xlrd
import xlwt
from datetime import datetime
import random
import concurrent.futures
import re
import json
import threading
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
import selenium.webdriver.support.expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.action_chains import ActionChains

import util

is_use = False


class nhAirRegister:
    # 初始化控制器和浏览器
    def __init__(self):
        print(f"启动中")
        options = webdriver.ChromeOptions()
        options.add_experimental_option("excludeSwitches", ["enable-logging"])
        options.add_experimental_option("excludeSwitches", ["enable-automation", "enable-logging"])  # 上面两个可以同时设置
        options.add_argument("--headless")  # 无头模式
        prefs = {"profile.managed_default_content_settings.images": 2,
                 "profile.managed_default_content_settings.video": 2}  # 设置无图视频模式
        options.add_experimental_option("prefs", prefs)  # 加载无图模式设置
        options.add_argument("--disable-gpu")  # 上面代码就是为了将Chrome不弹出界面
        options.add_argument("--incognito")  # 无痕隐身模式
        options.add_argument("disable-cache")  # 禁用缓存
        options.add_argument("disable-infobars")
        options.add_argument("log-level=3")
        options.add_argument("--disable-software-rasterizer")
        options.set_capability('goog:loggingPrefs', {'performance': 'ALL'})
        # mobileEmulation = {
        #     "deviceMetrics": {"width": 360, "height": 640, "pixelRatio": 3.0}
        # }
        # options.add_experimental_option("mobileEmulation", mobileEmulation)
        service = Service(executable_path="chromedriver.exe")
        self.browser = webdriver.Chrome(service=service, options=options)
        with open("./stealth.min.js") as f:
            js = f.read()
        self.browser.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {"source": js})
        self.browser.set_window_size(width=300, height=800)
        self.browser.set_window_position(x=0, y=0)
        print(f"启动完毕")

    # 开始
    def start(self, video_id, file_name_str, file_path):
        global is_use
        all_datas = []
        # 设置页面加载超时时间为10秒
        self.browser.set_page_load_timeout(30)
        self.browser.get(f"https://www.youtube.com/watch?v={video_id}")
        # 移除video
        count_elements = self.browser.find_elements(By.CSS_SELECTOR, "video")
        for video in count_elements:
            self.browser.execute_script("arguments[0].parentNode.removeChild(arguments[0])", video)
        # 等待网页加载完成
        time.sleep(10)
        # 移除video
        count_elements = self.browser.find_elements(By.CSS_SELECTOR, "video")
        for video in count_elements:
            self.browser.execute_script("arguments[0].parentNode.removeChild(arguments[0])", video)
        yt_initial_data = self.browser.execute_script("return window.ytInitialData")
        text_data = util.deep_search(yt_initial_data, "attributedDescriptionBodyText")
        time_data = util.deep_search(yt_initial_data, "publishDate")
        like_data = util.deep_search(yt_initial_data, "factoid")
        text = ""
        like = 0
        time_str = ""
        if text_data:
            text = text_data["content"]
        if like_data:
            like = like_data[0]['factoidRenderer']["value"]["simpleText"]
        if time_data:
            time_str = time_data['simpleText']
        # 先滚动加载出评论
        for _ in range(3):
            # 滚动到页面底部
            self.browser.execute_script("window.scrollBy(0,10000)")
            # 等待页面加载
            time.sleep(2)
        # 使用查询选择器获取元素
        count_elements = self.browser.find_elements(By.CSS_SELECTOR, "yt-formatted-string.ytd-comments-header-renderer")
        num = 10
        # 如果找到了元素
        if count_elements:
            # 获取第一个元素的内部 HTML
            count_html = count_elements[0].get_attribute("innerHTML")
            # 使用正则表达式提取数字部分
            match = re.search(r'<span[^>]*>([\d,]+)<\/span>', count_html)
            if match:
                number_string = match.group(1)  # 提取匹配的数字字符串
                print(f"{video_id}总评论数量：{number_string}")
                # 使用正则表达式匹配数字部分并去除非数字字符
                number_string = re.sub(r'\D', '', number_string)
                # 将去除非数字字符后的字符串转换为整数
                number = int(number_string)
                num = int(number / 40)
                if num > 80:
                    num = 80
            else:
                print(f"{video_id} 未找评论数量")
                return
        # 模拟向下滚动
        print(f"{video_id} 滚动：{num}")
        for _ in range(num):
            # 判断没有更多数据
            if 'Comments are turned off' in self.browser.page_source:
                break
            # 滚动到页面底部
            self.browser.execute_script("window.scrollBy(0,10000)")
            # 等待页面加载
            time.sleep(2)
        time.sleep(2)
        # 获取所有网络请求记录
        logs = self.browser.get_log('performance')
        # 解析请求，获取响应体信息
        for log in logs:
            message = json.loads(log['message'])['message']
            if 'Network.responseReceived' in message['method']:
                if 'response' in message['params']:
                    response_url = message['params']['response']['url']
                    if response_url == 'https://www.youtube.com/youtubei/v1/next?prettyPrint=false':
                        body = self.browser.execute_cdp_cmd("Network.getResponseBody",
                                                            {"requestId": message['params']['requestId']})['body']
                        # 请求响应的数据
                        json_body = json.loads(body)
                        # 剥洋葱
                        if 'frameworkUpdates' in json_body:
                            if 'entityBatchUpdate' in json_body['frameworkUpdates']:
                                try:
                                    datas = json_body['frameworkUpdates']['entityBatchUpdate']['mutations']
                                    for item in datas:
                                        if "commentEntityPayload" in item["payload"]:
                                            data = item["payload"]["commentEntityPayload"]['properties']
                                            content = data['content']['content']
                                            authorID = data["authorButtonA11y"]
                                            comment_time = data['publishedTime']
                                            all_datas.append({'authorID': authorID, 'content': content,
                                                              'comment_time': comment_time})
                                            # print({'authorID':authorID, 'content':content, 'comment_time':comment_time})
                                except:
                                    pass
        print(f'{video_id}  数据条数：{len(all_datas)}')
        while True:
            if not is_use:
                is_use = True
                break
            time.sleep(random.randint(1, 30) * 0.1)
        # try:
        # 写数据
        str_all_datas = json.dumps(all_datas, ensure_ascii=False)
        data_cells = {}
        data_cells["upload_time"] = time_str
        data_cells["description"] = text
        data_cells["count_like"] = like
        data_cells["count_comment"] = len(all_datas)
        data_cells["comment"] = f"file/{file_name_str}/{video_id}.json"
        util.update_csv_row(file_path, video_id, data_cells)
        if not os.path.exists(f"file/{file_name_str}"):
            os.mkdir(f"file/{file_name_str}")
        with open(f"file/{file_name_str}/{video_id}.json", 'w', encoding='utf-8') as file:
            file.write(str_all_datas)
        # except:
        #     print(f"{video_id} 失败")
        # finally:
        is_use = False

    # 后面不用管
    def wait(self, value, timeout=20):
        b = self.browser
        res = True
        try:
            WebDriverWait(b, timeout, 0.5).until(lambda b: b.find_element(By.XPATH, value))
            res = True
        except Exception as e:
            res = False
        return res

    def find_element(self, xpath):
        return self.browser.find_element(By.XPATH, xpath)

    def find_elements(self, xpath):
        return self.browser.find_elements(By.XPATH, xpath)

    def goBottom(self):
        self.browser.execute_script("window.scrollTo(0,document.body.scrollHeight);")

    def close(self):
        self.browser.quit()
